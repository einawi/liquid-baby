package com.liquid.liquidbaby

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

/** Pairing keys (kept out of the settings export). Keys are encrypted with the Android Keystore. */
object PairStore {
    private lateinit var sp: SharedPreferences

    fun init(ctx: Context) {
        sp = ctx.getSharedPreferences("pairing", Context.MODE_PRIVATE)
    }

    private fun idFor(key: String): String {
        var id = sp.getString(key, null)
        if (id == null) {
            id = Hex.encode(Crypto.random(16))
            sp.edit().putString(key, id).apply()
        }
        return id
    }

    class Peer(val id: String, val name: String, val key: String)

    class Paired(val childId: String, val childName: String, val parentId: String, val key: String, val lastIp: String)

    fun unitId(): String = idFor("unitId")

    fun parentId(): String = idFor("parentId")

    @Synchronized
    fun parents(): List<Peer> {
        val out = ArrayList<Peer>()
        try {
            val a = JSONArray(sp.getString("parents", "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(Peer(o.getString("id"), o.optString("name"), Vault.dec(o.getString("key"))))
            }
        } catch (e: Exception) {
            Diag.e("Could not read paired parents", e)
        }
        return out
    }

    @Synchronized
    private fun saveParents(list: List<Peer>) {
        val a = JSONArray()
        for (p in list) a.put(JSONObject().put("id", p.id).put("name", p.name).put("key", Vault.enc(p.key)))
        sp.edit().putString("parents", a.toString()).commit()
    }

    fun addParent(p: Peer) {
        val list = parents().filter { it.id != p.id }.toMutableList()
        list.add(p)
        saveParents(list)
    }

    fun removeParent(id: String) = saveParents(parents().filter { it.id != id })

    fun keyFor(id: String): ByteArray? {
        val p = parents().firstOrNull { it.id == id } ?: return null
        return try {
            Hex.decode(p.key)
        } catch (e: Exception) {
            null
        }
    }

    // ---- parent side ----

    fun paired(): Paired? {
        val childId = sp.getString("childId", null) ?: return null
        val stored = sp.getString("childKey", null) ?: return null
        return Paired(
            childId, sp.getString("childName", "") ?: "", parentId(), Vault.dec(stored),
            sp.getString("childIp", "") ?: ""
        )
    }

    fun savePaired(childId: String, childName: String, key: String, ip: String) {
        sp.edit().putString("childId", childId).putString("childName", childName)
            .putString("childKey", Vault.enc(key)).putString("childIp", ip).remove("lastSyncTs").commit()
    }

    /** Time of the newest clip this parent phone has already received (kept even if the clip is deleted). */
    fun lastSyncTs(): Long = sp.getLong("lastSyncTs", 0L)

    @Synchronized
    fun raiseLastSyncTs(v: Long) {
        if (v > sp.getLong("lastSyncTs", 0L)) sp.edit().putLong("lastSyncTs", v).commit()
    }

    fun setLastIp(ip: String) {
        val old = (sp.getString("childIps", "") ?: "").split(",").filter { it.isNotBlank() && it != ip }
        val list = (listOf(ip) + old).take(5)
        sp.edit().putString("childIp", ip).putString("childIps", list.joinToString(",")).apply()
    }

    /** Addresses the child phone had recently (its address can change on the router). */
    fun rememberedIps(): List<String> {
        val list = (sp.getString("childIps", "") ?: "").split(",").filter { it.isNotBlank() }
        if (list.isNotEmpty()) return list
        val one = sp.getString("childIp", "") ?: ""
        return if (one.isNotEmpty()) listOf(one) else emptyList()
    }

    fun clearPaired() {
        sp.edit().remove("childId").remove("childName").remove("childKey").remove("childIp").remove("childIps").remove("lastSyncTs").commit()
    }

    /** Deletes made while the child phone was not reachable; sent when it connects again. */
    fun pendingDeletes(): List<Long> =
        (sp.getString("pendingDel", "") ?: "").split(",").mapNotNull { it.trim().toLongOrNull() }

    fun setPendingDeletes(list: List<Long>) {
        sp.edit().putString("pendingDel", list.takeLast(500).joinToString(",")).apply()
    }
}
