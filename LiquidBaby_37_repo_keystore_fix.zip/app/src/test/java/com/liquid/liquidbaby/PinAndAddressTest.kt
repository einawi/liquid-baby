package com.liquid.liquidbaby

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** PIN hashing, IPv4 entry and size formatting: pure logic, runs on the JVM in GitHub Actions. */
class PinAndAddressTest {

    @Test
    fun samePinAndSaltGiveTheSameHash() {
        assertEquals(Lock.hash("ab12", "1234"), Lock.hash("ab12", "1234"))
    }

    @Test
    fun differentPinsGiveDifferentHashes() {
        assertNotEquals(Lock.hash("ab12", "1234"), Lock.hash("ab12", "1235"))
    }

    @Test
    fun differentSaltsGiveDifferentHashesForTheSamePin() {
        assertNotEquals(Lock.hash("ab12", "1234"), Lock.hash("cd34", "1234"))
    }

    @Test
    fun hashIsSixtyFourLowerCaseHexDigits() {
        val h = Lock.hash("00ff", "1234")
        assertEquals(64, h.length)
        assertTrue(h.all { it in "0123456789abcdef" })
    }

    @Test
    fun hashNeverContainsThePinItself() {
        assertFalse(Lock.hash("ab12", "4821").contains("4821"))
    }

    @Test
    fun ipAcceptsSurroundingSpacesAndRejectsBadValues() {
        assertTrue(Ip.isValid(" 192.168.1.101 "))
        assertFalse(Ip.isValid("192.168.1.256"))
        assertFalse(Ip.isValid("192.168.1"))
        assertFalse(Ip.isValid("abc"))
        assertFalse(Ip.isValid(""))
    }

    @Test
    fun sameSubnetNeedsTheFirstThreeNumbersToMatch() {
        assertTrue(Ip.sameSubnet24("192.168.1.5", "192.168.1.200"))
        assertFalse(Ip.sameSubnet24("192.168.1.5", "192.168.2.5"))
        assertFalse(Ip.sameSubnet24("bad", "192.168.1.5"))
    }

    @Test
    fun formatSizeAtTheUnitBoundaries() {
        assertEquals("1023 B", VersionUtil.formatSize(1023))
        assertEquals("1 KB", VersionUtil.formatSize(1024))
        assertEquals("1.0 MB", VersionUtil.formatSize(1024L * 1024))
    }
}
