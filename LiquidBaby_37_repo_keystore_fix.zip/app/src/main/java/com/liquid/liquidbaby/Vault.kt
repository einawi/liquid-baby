package com.liquid.liquidbaby

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** Encrypts small secrets with a key kept in the Android Keystore. Plain values stored by older builds still read. */
object Vault {
    private const val ALIAS = "liquidbaby_vault"

    /** True when the Keystore could not encrypt on this phone. */
    @Volatile
    var failed = false

    /** The Keystore key used for clip files and pairing keys. */
    fun storageKey(): SecretKey = key()

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore")
        ks.load(null)
        val existing = ks.getKey(ALIAS, null)
        if (existing is SecretKey) return existing
        val g = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        g.init(
            KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return g.generateKey()
    }

    fun enc(plain: String): String = try {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, key())
        val ct = c.doFinal(plain.toByteArray())
        "v1:" + Base64.encodeToString(c.iv + ct, Base64.NO_WRAP)
    } catch (e: Exception) {
        failed = true
        Diag.e("Keystore encryption failed, storing without encryption", e)
        plain
    }

    /** True only when the Keystore can encrypt on this phone; pairing refuses to store keys otherwise. */
    fun canStore(): Boolean {
        val probe = enc("check")
        return probe.startsWith("v1:")
    }

    fun dec(stored: String): String {
        if (!stored.startsWith("v1:")) return stored
        return try {
            val raw = Base64.decode(stored.substring(3), Base64.NO_WRAP)
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, raw.copyOfRange(0, 12)))
            String(c.doFinal(raw.copyOfRange(12, raw.size)))
        } catch (e: Exception) {
            Diag.e("Could not decrypt a pairing key", e)
            ""
        }
    }
}
